import type { Metadata } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter',
  display: 'swap',
});

const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: '--font-playfair',
  display: 'swap',
});

export const metadata: Metadata = {
  title: "Jimi's Gardens | Local Gardening Services Enfield London",
  description: "Trusted local gardening services across Enfield and Greater London since 2021. 9.97/10 Checkatrade rating from 78 verified reviews. Garden maintenance, clearance, lawn care & more. £1,000 guarantee.",
  keywords: "gardening services Enfield, garden maintenance London, lawn care EN1 EN2 EN3 EN8 EN10, hedge trimming, garden clearance Greater London, Jimi's Gardens",
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  openGraph: {
    title: "Jimi's Gardens | Local Gardening Services Enfield London",
    description: "Trusted local gardening services across Enfield and Greater London since 2021. 9.97/10 Checkatrade rating.",
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className="font-sans antialiased">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
