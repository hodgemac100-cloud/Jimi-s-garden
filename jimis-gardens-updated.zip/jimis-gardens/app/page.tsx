import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { TrustBar } from "@/components/trust-bar"
import { About } from "@/components/about"
import { Services } from "@/components/services"
import { Transformations } from "@/components/transformations"
import { Reviews } from "@/components/reviews"
import { WhyChooseUs } from "@/components/why-choose-us"
import { Gallery } from "@/components/gallery"
import { QuoteForm } from "@/components/quote-form"
import { Footer } from "@/components/footer"
import { MobileQuoteBar } from "@/components/mobile-quote-bar"

export default function Home() {
  return (
    <>
      {/* LocalBusiness Schema for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            name: "Jimi's Gardens",
            description:
              "Trusted local gardening services across Enfield and Greater London since 2021. Garden maintenance, clearance, lawn care, hedge trimming and more.",
            founder: {
              "@type": "Person",
              name: "Qerim Dogjani",
            },
            foundingDate: "2021",
            address: {
              "@type": "PostalAddress",
              addressLocality: "Enfield",
              addressRegion: "Greater London",
              addressCountry: "GB",
            },
            areaServed: [
              "Enfield",
              "Greater London",
              "EN1",
              "EN2",
              "EN3",
              "EN8",
              "EN10",
            ],
            aggregateRating: {
              "@type": "AggregateRating",
              ratingValue: "9.97",
              bestRating: "10",
              worstRating: "1",
              ratingCount: "78",
            },
            hasOfferCatalog: {
              "@type": "OfferCatalog",
              name: "Gardening Services",
              itemListElement: [
                {
                  "@type": "Offer",
                  itemOffered: {
                    "@type": "Service",
                    name: "Garden Maintenance",
                  },
                },
                {
                  "@type": "Offer",
                  itemOffered: {
                    "@type": "Service",
                    name: "Garden Clearance",
                  },
                },
                {
                  "@type": "Offer",
                  itemOffered: {
                    "@type": "Service",
                    name: "Lawn Care",
                  },
                },
                {
                  "@type": "Offer",
                  itemOffered: {
                    "@type": "Service",
                    name: "Hedge Trimming",
                  },
                },
              ],
            },
          }),
        }}
      />

      <main className="pb-16 md:pb-0">
        <Navbar />
        <Hero />
        <TrustBar />
        <About />
        <Services />
        <Transformations />
        <Reviews />
        <WhyChooseUs />
        <Gallery />
        <QuoteForm />
        <Footer />
        <MobileQuoteBar />
      </main>
    </>
  )
}
