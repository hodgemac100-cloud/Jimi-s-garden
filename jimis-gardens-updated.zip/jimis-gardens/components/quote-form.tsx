"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { CheckCircle, Loader2 } from "lucide-react"

const services = [
  "Garden Maintenance",
  "Garden Clearance",
  "Hedge Trimming & Removal",
  "Lawn Care",
  "Weed Control",
  "Garden Logs Supplied & Delivered",
  "Roof Gardens",
  "Pruning",
  "Scarification",
  "Lawn Aeration",
  "Emergency Garden Service",
]

export function QuoteForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    postcode: "",
    service: "",
    description: "",
    contactPreference: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  if (isSubmitted) {
    return (
      <section id="contact" className="py-20 bg-[#1a3d2b]">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-2xl p-8 md:p-12 text-center shadow-xl">
              <div className="w-20 h-20 bg-[#2d6a4f] rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h3 className="font-serif text-3xl font-bold text-[#1a3d2b] mb-4">
                Thank You!
              </h3>
              <p className="text-lg text-[#5a7d6a] mb-6">
                We&apos;ve received your request and will be in touch within 24 hours to discuss your garden needs.
              </p>
              <Button
                onClick={() => {
                  setIsSubmitted(false)
                  setFormData({
                    name: "",
                    phone: "",
                    email: "",
                    postcode: "",
                    service: "",
                    description: "",
                    contactPreference: "",
                  })
                }}
                className="bg-[#1a3d2b] hover:bg-[#2d6a4f] text-white"
              >
                Submit Another Request
              </Button>
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="contact" className="py-20 bg-[#1a3d2b]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4 text-balance">
            Get Your Free Quote
          </h2>
          <p className="text-lg text-white/80 max-w-2xl mx-auto">
            Tell us about your garden and we&apos;ll get back to you within 24 hours
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <form
            onSubmit={handleSubmit}
            className="bg-white rounded-2xl p-8 md:p-12 shadow-xl"
          >
            <div className="grid sm:grid-cols-2 gap-6 mb-6">
              <div>
                <label
                  htmlFor="name"
                  className="block text-sm font-semibold text-[#1a3d2b] mb-2"
                >
                  Full Name *
                </label>
                <Input
                  id="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => handleChange("name", e.target.value)}
                  className="border-[#d4d0c8] focus:border-[#2d6a4f] focus:ring-[#2d6a4f]"
                  placeholder="John Smith"
                />
              </div>
              <div>
                <label
                  htmlFor="phone"
                  className="block text-sm font-semibold text-[#1a3d2b] mb-2"
                >
                  Phone Number *
                </label>
                <Input
                  id="phone"
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => handleChange("phone", e.target.value)}
                  className="border-[#d4d0c8] focus:border-[#2d6a4f] focus:ring-[#2d6a4f]"
                  placeholder="07123 456789"
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-6 mb-6">
              <div>
                <label
                  htmlFor="email"
                  className="block text-sm font-semibold text-[#1a3d2b] mb-2"
                >
                  Email Address *
                </label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  className="border-[#d4d0c8] focus:border-[#2d6a4f] focus:ring-[#2d6a4f]"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label
                  htmlFor="postcode"
                  className="block text-sm font-semibold text-[#1a3d2b] mb-2"
                >
                  Postcode *
                </label>
                <Input
                  id="postcode"
                  type="text"
                  required
                  value={formData.postcode}
                  onChange={(e) => handleChange("postcode", e.target.value)}
                  className="border-[#d4d0c8] focus:border-[#2d6a4f] focus:ring-[#2d6a4f]"
                  placeholder="EN1 1AB"
                />
              </div>
            </div>

            <div className="mb-6">
              <label
                htmlFor="service"
                className="block text-sm font-semibold text-[#1a3d2b] mb-2"
              >
                Service Required *
              </label>
              <Select
                value={formData.service}
                onValueChange={(value) => handleChange("service", value)}
                required
              >
                <SelectTrigger className="border-[#d4d0c8] focus:border-[#2d6a4f] focus:ring-[#2d6a4f]">
                  <SelectValue placeholder="Select a service" />
                </SelectTrigger>
                <SelectContent>
                  {services.map((service) => (
                    <SelectItem key={service} value={service}>
                      {service}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="mb-6">
              <label
                htmlFor="description"
                className="block text-sm font-semibold text-[#1a3d2b] mb-2"
              >
                Tell Us About Your Garden
              </label>
              <Textarea
                id="description"
                rows={4}
                value={formData.description}
                onChange={(e) => handleChange("description", e.target.value)}
                className="border-[#d4d0c8] focus:border-[#2d6a4f] focus:ring-[#2d6a4f]"
                placeholder="Describe your garden, the work needed, and any specific requirements..."
              />
            </div>

            <div className="mb-8">
              <label className="block text-sm font-semibold text-[#1a3d2b] mb-2">
                Preferred Contact Method
              </label>
              <div className="flex gap-4">
                {["Phone", "Email", "Either"].map((option) => (
                  <label
                    key={option}
                    className="flex items-center gap-2 cursor-pointer"
                  >
                    <input
                      type="radio"
                      name="contactPreference"
                      value={option}
                      checked={formData.contactPreference === option}
                      onChange={(e) =>
                        handleChange("contactPreference", e.target.value)
                      }
                      className="w-4 h-4 text-[#2d6a4f] focus:ring-[#2d6a4f]"
                    />
                    <span className="text-[#5a7d6a]">{option}</span>
                  </label>
                ))}
              </div>
            </div>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#1a3d2b] hover:bg-[#2d6a4f] text-white font-semibold py-6 text-lg transition-transform hover:scale-[1.02]"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Request My Free Quote"
              )}
            </Button>
          </form>
        </div>
      </div>
    </section>
  )
}
