"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { CheckCircle, Award, Shield } from "lucide-react"

const badges = [
  { icon: CheckCircle, label: "Checkatrade Verified" },
  { icon: Award, label: "5 Years Experience" },
  { icon: Shield, label: "£1,000 Guarantee" },
]

export function About() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      id="about"
      ref={sectionRef}
      className="py-20 bg-white"
    >
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div
            className={`relative aspect-[4/3] rounded-lg overflow-hidden shadow-xl transition-all duration-700 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
            }`}
          >
            <Image
              src="/images/about-garden.jpg"
              alt="Beautiful maintained garden by Jimi's Gardens"
              fill
              className="object-cover"
            />
          </div>

          {/* Content */}
          <div
            className={`transition-all duration-700 delay-200 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
            }`}
          >
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#1a3d2b] mb-6 text-balance">
              Your Local Garden Experts
            </h2>
            <p className="text-lg text-[#5a7d6a] mb-6 leading-relaxed">
              Founded in 2021 by Mr. Qerim Dogjani, Jimi&apos;s Gardens has become one of Enfield&apos;s most trusted local gardeners. With 78 verified Checkatrade jobs and a 9.97/10 rating, we&apos;ve built our reputation on quality work and reliability.
            </p>
            <p className="text-lg text-[#5a7d6a] mb-8 leading-relaxed">
              We show up on time, work hard, and leave your garden spotless every single time. Whether you need regular maintenance or a complete garden transformation, we&apos;re here to help.
            </p>

            {/* Badges */}
            <div className="flex flex-wrap gap-4">
              {badges.map((badge, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 bg-[#f9f6f0] px-4 py-2 rounded-full"
                >
                  <badge.icon className="w-5 h-5 text-[#2d6a4f]" />
                  <span className="text-sm font-semibold text-[#1a3d2b]">
                    {badge.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
