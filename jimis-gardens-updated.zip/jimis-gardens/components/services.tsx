"use client"

import { useEffect, useRef, useState } from "react"
import {
  Leaf,
  Trash2,
  Scissors,
  Flower2,
  Bug,
  TreeDeciduous,
  Building2,
  SproutIcon,
  Waves,
  Wind,
  AlertTriangle,
} from "lucide-react"

const services = [
  {
    icon: Leaf,
    name: "Garden Maintenance",
    description: "Regular upkeep to keep your garden looking its best all year round.",
  },
  {
    icon: Trash2,
    name: "Garden Clearance",
    description: "Complete garden clearance and waste removal for overgrown spaces.",
  },
  {
    icon: Scissors,
    name: "Hedge Trimming & Removal",
    description: "Professional hedge cutting, shaping, and complete removal services.",
  },
  {
    icon: Flower2,
    name: "Lawn Care",
    description: "Expert lawn maintenance including mowing, feeding, and treatment.",
  },
  {
    icon: Bug,
    name: "Weed Control",
    description: "Effective weed prevention and removal to protect your garden.",
  },
  {
    icon: TreeDeciduous,
    name: "Garden Logs Supplied & Delivered",
    description: "Quality seasoned logs for your fire, delivered to your door.",
  },
  {
    icon: Building2,
    name: "Roof Gardens",
    description: "Design and maintenance for beautiful urban rooftop gardens.",
  },
  {
    icon: SproutIcon,
    name: "Pruning",
    description: "Expert pruning for shrubs, trees, and plants to promote healthy growth.",
  },
  {
    icon: Waves,
    name: "Scarification",
    description: "Remove thatch and moss to revive and rejuvenate your lawn.",
  },
  {
    icon: Wind,
    name: "Lawn Aeration",
    description: "Improve soil drainage and root health with professional aeration.",
  },
  {
    icon: AlertTriangle,
    name: "Emergency Garden Service",
    description: "Rapid response for storm damage, fallen trees, and urgent garden issues.",
  },
]

export function Services() {
  const [visibleItems, setVisibleItems] = useState<number[]>([])
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          services.forEach((_, index) => {
            setTimeout(() => {
              setVisibleItems((prev) => [...prev, index])
            }, index * 100)
          })
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="services" ref={sectionRef} className="py-20 bg-[#f9f6f0]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#1a3d2b] mb-4 text-balance">
            Our Services
          </h2>
          <p className="text-lg text-[#5a7d6a] max-w-2xl mx-auto">
            Complete gardening solutions for homes across Enfield and Greater London
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div
              key={index}
              className={`bg-white rounded-lg p-6 shadow-sm transition-all duration-500 hover:shadow-lg hover:-translate-y-1 hover:border-l-4 hover:border-l-[#2d6a4f] cursor-pointer ${
                visibleItems.includes(index)
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
            >
              <div className="w-12 h-12 bg-[#f9f6f0] rounded-lg flex items-center justify-center mb-4">
                <service.icon className="w-6 h-6 text-[#2d6a4f]" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-[#1a3d2b] mb-2">
                {service.name}
              </h3>
              <p className="text-[#5a7d6a]">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
