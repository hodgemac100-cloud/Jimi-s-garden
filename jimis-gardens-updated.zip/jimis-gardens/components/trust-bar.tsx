"use client"

import { Star, CheckCircle, Shield, MapPin, Calendar } from "lucide-react"

const trustSignals = [
  {
    icon: Star,
    label: "9.97/10",
    sublabel: "Checkatrade Rating",
  },
  {
    icon: CheckCircle,
    label: "78",
    sublabel: "Verified Reviews",
  },
  {
    icon: Shield,
    label: "£1,000",
    sublabel: "Guarantee",
  },
  {
    icon: MapPin,
    label: "Enfield",
    sublabel: "& Greater London",
  },
  {
    icon: Calendar,
    label: "Since 2021",
    sublabel: "Trading",
  },
]

export function TrustBar() {
  return (
    <section className="bg-[#f9f6f0] py-6 border-y border-[#e8e4da]">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center items-center gap-6 md:gap-12">
          {trustSignals.map((signal, index) => (
            <div
              key={index}
              className="flex items-center gap-3 text-[#1a3d2b]"
            >
              <signal.icon className="w-5 h-5 text-[#2d6a4f]" />
              <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2">
                <span className="font-bold text-lg">{signal.label}</span>
                <span className="text-sm text-[#5a7d6a]">{signal.sublabel}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
