"use client"

import { useEffect, useRef, useState } from "react"
import { Star, Quote } from "lucide-react"

function useCountUp(target: number, duration: number, start: boolean, decimals = 0) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    if (!start) return
    let startTime: number | null = null
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp
      const progress = Math.min((timestamp - startTime) / duration, 1)
      // Ease out: starts fast, slows near end
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(parseFloat((eased * target).toFixed(decimals)))
      if (progress < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [start, target, duration, decimals])

  return count
}

const reviews = [
  {
    name: "Tony H",
    location: "EN10",
    rating: 10,
    text: "Jimi came to clear my very overgrown garden. He made a wonderful job and left the garden spotless. Would recommend and will use again.",
  },
  {
    name: "Alex C",
    location: "RM9",
    rating: 10,
    text: "Jimi and team were great. Fast, efficient and clean. Would highly recommend and will use again.",
  },
  {
    name: "Karen L",
    location: "IG10",
    rating: 10,
    text: "Excellent service, would highly recommend.",
  },
  {
    name: "Mick R",
    location: "CM18",
    rating: 9.67,
    text: "Jimmy came round, gave us a quote and a date, turned up on time and carried out the work with no problems.",
  },
  {
    name: "George G",
    location: "EN10",
    rating: 10,
    text: "Excellent service. Highly recommend Jimi.",
  },
]

function ReviewCard({ review }: { review: typeof reviews[0] }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm min-w-[320px] max-w-[400px] flex-shrink-0">
      <div className="flex items-start gap-4 mb-4">
        <div className="w-12 h-12 bg-[#f9f6f0] rounded-full flex items-center justify-center">
          <Quote className="w-5 h-5 text-[#2d6a4f]" />
        </div>
        <div>
          <h4 className="font-semibold text-[#1a3d2b]">{review.name}</h4>
          <p className="text-sm text-[#5a7d6a]">{review.location}</p>
        </div>
        <div className="ml-auto flex items-center gap-1 bg-[#f9f6f0] px-3 py-1 rounded-full">
          <Star className="w-4 h-4 text-[#c9a227] fill-current" />
          <span className="text-sm font-bold text-[#1a3d2b]">{review.rating}/10</span>
        </div>
      </div>
      <p className="text-[#5a7d6a] leading-relaxed">&quot;{review.text}&quot;</p>
    </div>
  )
}

export function Reviews() {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [isPaused, setIsPaused] = useState(false)

  useEffect(() => {
    const scrollContainer = scrollRef.current
    if (!scrollContainer) return

    let animationId: number
    let scrollPosition = 0

    const scroll = () => {
      if (!isPaused && scrollContainer) {
        scrollPosition += 0.5
        if (scrollPosition >= scrollContainer.scrollWidth / 2) {
          scrollPosition = 0
        }
        scrollContainer.scrollLeft = scrollPosition
      }
      animationId = requestAnimationFrame(scroll)
    }

    animationId = requestAnimationFrame(scroll)

    return () => cancelAnimationFrame(animationId)
  }, [isPaused])

  return (
    <section id="reviews" className="py-20 bg-[#f9f6f0]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#1a3d2b] mb-4 text-balance">
            What Our Customers Say
          </h2>
          <p className="text-lg text-[#5a7d6a] max-w-2xl mx-auto">
            Real reviews from real customers on Checkatrade
          </p>
        </div>
      </div>

      {/* Scrolling Reviews */}
      <div
        ref={scrollRef}
        className="overflow-hidden"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        <div className="flex gap-6 px-4">
          {/* Double the reviews for infinite scroll effect */}
          {[...reviews, ...reviews].map((review, index) => (
            <ReviewCard key={index} review={review} />
          ))}
        </div>
      </div>

      {/* Animated Stats */}
      <AnimatedStats />
    </section>
  )
}

function AnimatedStats() {
  const [hasStarted, setHasStarted] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setHasStarted(true)
          observer.disconnect()
        }
      },
      { threshold: 0.5 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  const rating = useCountUp(9.97, 2000, hasStarted, 2)
  const reviewCount = useCountUp(78, 2000, hasStarted, 0)

  return (
    <div className="container mx-auto px-4 mt-16" ref={ref}>
      <div className="bg-white rounded-2xl p-8 text-center shadow-sm max-w-2xl mx-auto">
        <div className="flex items-center justify-center gap-2 mb-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star key={star} className="w-8 h-8 text-[#c9a227] fill-current" />
          ))}
        </div>
        <p className="font-serif text-4xl md:text-5xl font-bold text-[#1a3d2b] mb-2">
          {rating.toFixed(2)}/10
        </p>
        <p className="text-lg text-[#5a7d6a]">
          from {Math.round(reviewCount)} Verified Checkatrade Reviews
        </p>
      </div>
    </div>
  )
}
