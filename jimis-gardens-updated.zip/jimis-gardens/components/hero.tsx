"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Hero() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero-garden.jpg"
          alt="Perfectly striped lawn with tropical planting borders completed by Jimi's Gardens in Enfield"
          fill
          className="object-cover object-center"
          priority
        />
        {/* Gradient Overlay - warm dark green on bottom third */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a3d2b]/90 via-[#1a3d2b]/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 pt-32 pb-20 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Small Label */}
          <p
            className={`uppercase text-sm tracking-widest text-[#c9a227] font-semibold mb-6 transition-all duration-700 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Checkatrade Verified · Enfield, Greater London
          </p>

          {/* Main Heading */}
          <h1
            className={`font-serif text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 text-balance transition-all duration-700 delay-100 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Your Garden, Transformed.
          </h1>

          {/* Subheading */}
          <p
            className={`text-xl md:text-2xl text-white/90 mb-10 max-w-2xl mx-auto text-pretty transition-all duration-700 delay-200 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Trusted local gardening services across Enfield and Greater London since 2021.
          </p>

          {/* CTA Buttons */}
          <div
            className={`flex flex-col sm:flex-row gap-4 justify-center transition-all duration-700 delay-300 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            <Link href="#contact">
              <Button
                size="lg"
                className="bg-white text-[#1a3d2b] hover:bg-[#f9f6f0] font-semibold px-8 py-6 text-lg transition-transform hover:scale-105 border border-black"
              >
                Request a Free Quote
              </Button>
            </Link>
            <Link href="#transformations">
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white/10 font-semibold px-8 py-6 text-lg bg-transparent transition-transform hover:scale-105"
              >
                See Our Work
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
