"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone } from "lucide-react"

export function MobileQuoteBar() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-white border-t border-[#d4d0c8] p-3 shadow-lg">
      <div className="flex gap-3">
        <a href="tel:07123456789" className="flex-1">
          <Button
            variant="outline"
            className="w-full border-[#1a3d2b] text-[#1a3d2b] hover:bg-[#f9f6f0]"
          >
            <Phone className="w-4 h-4 mr-2" />
            Call Now
          </Button>
        </a>
        <Link href="#contact" className="flex-1">
          <Button className="w-full bg-[#1a3d2b] hover:bg-[#2d6a4f] text-white">
            Free Quote
          </Button>
        </Link>
      </div>
    </div>
  )
}
