"use client"

import { useEffect, useRef, useState } from "react"
import { CheckCircle, Star, Clock, Shield } from "lucide-react"

const reasons = [
  {
    icon: CheckCircle,
    title: "Fully Vetted",
    description: "Checkatrade verified with all credentials checked and confirmed.",
  },
  {
    icon: Star,
    title: "Near-Perfect Rating",
    description: "9.97/10 average rating from 78 verified customer reviews.",
  },
  {
    icon: Clock,
    title: "Reliable & Punctual",
    description: "We show up on time, every time. Your schedule is our priority.",
  },
  {
    icon: Shield,
    title: "£1,000 Guarantee",
    description: "Protected by Checkatrade's £1,000 guarantee for your peace of mind.",
  },
]

export function WhyChooseUs() {
  const [visibleItems, setVisibleItems] = useState<number[]>([])
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          reasons.forEach((_, index) => {
            setTimeout(() => {
              setVisibleItems((prev) => [...prev, index])
            }, index * 150)
          })
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-[#1a3d2b] mb-4 text-balance">
            Why Choose Jimi&apos;s Gardens?
          </h2>
          <p className="text-lg text-[#5a7d6a] max-w-2xl mx-auto">
            We&apos;re not just another gardening company — we&apos;re your trusted local experts
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className={`text-center transition-all duration-500 ${
                visibleItems.includes(index)
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
            >
              <div className="w-16 h-16 bg-[#f9f6f0] rounded-full flex items-center justify-center mx-auto mb-4">
                <reason.icon className="w-8 h-8 text-[#2d6a4f]" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-[#1a3d2b] mb-2">
                {reason.title}
              </h3>
              <p className="text-[#5a7d6a]">{reason.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
