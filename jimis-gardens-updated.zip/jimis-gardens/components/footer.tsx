"use client"

import Link from "next/link"
import { Leaf, Phone, Mail, MapPin, Facebook, Instagram, Twitter } from "lucide-react"

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-[#1a3d2b] text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Logo & About */}
          <div>
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                <Leaf className="w-5 h-5 text-[#1a3d2b]" />
              </div>
              <span className="font-serif text-xl font-bold">Jimi&apos;s Gardens</span>
            </Link>
            <p className="text-white/70 mb-4 leading-relaxed">
              Trusted local gardening services across Enfield and Greater London since 2021.
            </p>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-serif text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <Link href="#about" className="text-white/70 hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#services" className="text-white/70 hover:text-white transition-colors">
                  Our Services
                </Link>
              </li>
              <li>
                <Link href="#reviews" className="text-white/70 hover:text-white transition-colors">
                  Reviews
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-white/70 hover:text-white transition-colors">
                  Get a Quote
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-serif text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-3">
              <li>
                <Link href="#services" className="text-white/70 hover:text-white transition-colors">
                  Garden Maintenance
                </Link>
              </li>
              <li>
                <Link href="#services" className="text-white/70 hover:text-white transition-colors">
                  Garden Clearance
                </Link>
              </li>
              <li>
                <Link href="#services" className="text-white/70 hover:text-white transition-colors">
                  Lawn Care
                </Link>
              </li>
              <li>
                <Link href="#services" className="text-white/70 hover:text-white transition-colors">
                  Hedge Trimming
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif text-lg font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#c9a227] mt-0.5 flex-shrink-0" />
                <span className="text-white/70">
                  Enfield, Greater London
                  <br />
                  EN1, EN2, EN3, EN8, EN10
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[#c9a227] flex-shrink-0" />
                <a href="tel:07123456789" className="text-white/70 hover:text-white transition-colors">
                  07123 456789
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[#c9a227] flex-shrink-0" />
                <a
                  href="mailto:info@jimisgardens.co.uk"
                  className="text-white/70 hover:text-white transition-colors"
                >
                  info@jimisgardens.co.uk
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Checkatrade Badge */}
        <div className="border-t border-white/10 pt-8 mb-8">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-center">
            <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
              <svg
                viewBox="0 0 24 24"
                className="w-5 h-5 text-[#c9a227]"
                fill="currentColor"
              >
                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
              </svg>
              <span className="font-semibold">Checkatrade Verified</span>
            </div>
            <span className="text-white/70">
              9.97/10 Rating · 78 Verified Reviews · £1,000 Guarantee
            </span>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/10 pt-8 text-center">
          <p className="text-white/50 text-sm">
            © {currentYear} Jimi&apos;s Gardens. All rights reserved. Trading since 2021.
          </p>
        </div>
      </div>
    </footer>
  )
}
